package com.example.sportresult.ui.Country;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sportresult.Clases.Country;
import com.example.sportresult.Clases.Sport;
import com.example.sportresult.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CountryArrayAdapter extends ArrayAdapter<Country> {
    private static Context context;
    private List<Country> lista = null;
    public CountryArrayAdapter(Context context, List<Country> lista){
        super(context, R.layout.string_list_view,lista);


        this.context = context;
        this.lista = lista;
    }
    public View getView(int position, View view, ViewGroup parent){
        LayoutInflater inflater = LayoutInflater.from(context);
        View rowView = inflater.inflate(R.layout.string_list_view,null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title_country);

        titleText.setText(lista.get(position).getNameEn());

        return rowView;
    }
}
