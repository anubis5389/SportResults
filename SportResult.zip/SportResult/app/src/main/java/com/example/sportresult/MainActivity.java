package com.example.sportresult;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.ui.CountryLeague.CountryLeagueFragment;
import com.example.sportresult.ui.Sport.SportsFragment;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SportsFragment frgInicial = new SportsFragment();

        getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainer,frgInicial,"Sports").addToBackStack("SportList").commit();
    }

}
