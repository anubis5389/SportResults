package com.example.sportresult.API;

import android.content.Context;
import android.os.StrictMode;

import com.example.sportresult.Clases.Country;
import com.example.sportresult.Clases.CountryList;
import com.example.sportresult.Clases.Result;
import com.example.sportresult.Clases.EventList;
import com.example.sportresult.Clases.Sport;
import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.Clases.CountryLeagueList;
import com.example.sportresult.Clases.SportList;
import com.example.sportresult.Clases.Team;
import com.example.sportresult.Clases.TeamList;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private Context context;
    private Retrofit retrofit;


    public ApiClient(Context context){
        super();
        this.context = context;

         retrofit = new Retrofit.Builder()
                .baseUrl("https://www.thesportsdb.com/api/v1/json/1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public List<Sport> getAllSports() {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        SportList listaDeportes = new SportList();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<SportList> sportList = service.getAllSports();
        try {
            Response<SportList> response = sportList.execute();
            listaDeportes = response.body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return listaDeportes.getSports();
    }

    public List<Country> getAllCountries(){

        CountryList listaPaises = new CountryList();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<CountryList> countriesCall = service.getAllCountries();
        String asdf = countriesCall.request().url().toString();
        try{
            Response<CountryList> response = countriesCall.execute();
            listaPaises = response.body();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
        return listaPaises.getCountries();
    }

    public List<CountryLeague> getAllLeaguesForCountryAndSport(String sport, String country){

        CountryLeagueList listaLigas = new CountryLeagueList();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<CountryLeagueList> sportList = service.getAllLeaguesForCountryAndSport(sport, country);
        String asdf = sportList.request().url().toString();

        try{
            Response<CountryLeagueList> response = sportList.execute();
            listaLigas = response.body();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }

        return listaLigas.getCountrys();
    }
    public List<Team> getAllTeamFromLeague(String league){

        TeamList listaEquipos = new TeamList();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<TeamList> teamList = service.getAllTeamFromLeague(league);
        String asdf = teamList.request().url().toString();

        try{

            Response<TeamList> response = teamList.execute();
            listaEquipos = response.body();

        }catch(IOException ioe){
            ioe.printStackTrace();
        }

        return listaEquipos.getTeams();
    }
    public Team getTeamByName(String team){

        TeamList listaEquipos = new TeamList();
        Team equipo = new Team();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<TeamList> teamCall = service.getTeamByName(team);
        String debug = teamCall.request().url().toString();
        try{

            Response<TeamList> response = teamCall.execute();
            listaEquipos = response.body();


        }catch(IOException ioe){
            ioe.printStackTrace();
        }

        equipo = listaEquipos.getTeams().get(0);

        return equipo;
    }
    public List<Result> getLastEventsByTeamId(String teamId ){

        EventList eventList = new EventList();
        SportsDBGet service = retrofit.create(SportsDBGet.class);
        Call<EventList> eventListCall = service.getLastEventsByTeamId(teamId);
        String debug = eventListCall.request().url().toString();

        try{
            Response<EventList> response = eventListCall.execute();
            eventList = response.body();

        }catch(IOException ioe){
            ioe.printStackTrace();
        }

        return eventList.getResults();
    }
}
