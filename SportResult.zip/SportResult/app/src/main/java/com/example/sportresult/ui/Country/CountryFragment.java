package com.example.sportresult.ui.Country;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.Country;
import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.Clases.CountryList;
import com.example.sportresult.R;
import com.example.sportresult.ui.CountryLeague.CountryLeagueFragment;
import com.example.sportresult.ui.Sport.SportsFragment;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CountryFragment extends Fragment {
    private ListView listViewCountry;
    private ApiClient apiClient;
    public CountryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_country, container, false);

        listViewCountry = (ListView) root.findViewById(R.id.countryList);
        apiClient = new ApiClient(this.getContext());
        List<Country> countryLists = apiClient.getAllCountries();
        CountryArrayAdapter adapter = new CountryArrayAdapter(getContext(),countryLists);

        listViewCountry.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Country selectedCountry = (Country)listViewCountry.getItemAtPosition(position);
                Bundle args = getArguments();

                byte[] bytes = null;
                try{
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(bos);
                    List<CountryLeague> listaEquipos = apiClient.getAllLeaguesForCountryAndSport(args.getString("Sport"),selectedCountry.getNameEn());

                    if(listaEquipos != null){
                        oos.writeObject(listaEquipos);
                        bytes = bos.toByteArray();
                        oos.close();
                        bos.close();
                    }else{
                        Toast.makeText(getContext(),"Sin resultados, haga click en \"Atras\" ",Toast.LENGTH_LONG);
                    }


                    //savedInstanceState.putByteArray("Lista de ligas",bytes);
                }catch(Exception e){
                    e.printStackTrace();
                }


                if(bytes != null){
                    args.putByteArray("LeagueListForCountryAndSport",bytes);
                    CountryLeagueFragment fragment = new CountryLeagueFragment();
                    fragment.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragmentContainer,fragment).addToBackStack("CountryToLeague");
                    fragmentTransaction.commit();
                }else{
                    Toast.makeText(getContext(),"Sin resultados, haga click en \"Atras\" ",Toast.LENGTH_LONG);
                }

            }
        });
        try {
            listViewCountry.setAdapter(adapter);
        }catch(NullPointerException npe){
            npe.printStackTrace();
            SportsFragment aux = new SportsFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragmentContainer, aux).addToBackStack("BackToBegin");
            fragmentTransaction.commit();
        }

        return root;
    }
}
