package com.example.sportresult.ui.Team;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sportresult.Clases.Team;
import com.example.sportresult.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TeamArrayAdapter extends ArrayAdapter {
    private final Context context;
    private List<Team> lista = null;

    public TeamArrayAdapter(Context context, List<Team> lista){
        super(context, R.layout.custom_item_list,lista);

        this.context = context;
        this.lista = lista;
    }

    public View getView(int position, View view, ViewGroup parent){
        LayoutInflater inflater = LayoutInflater.from(context);
//        context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.custom_item_list,null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.subtitle);

        titleText.setText(lista.get(position).getStrTeam());
        Picasso.get().load(lista.get(position).getStrTeamBadge()).into(imageView);
        subtitleText.setText(lista.get(position).getStrDescriptionEN());

        return rowView;
    }
}
