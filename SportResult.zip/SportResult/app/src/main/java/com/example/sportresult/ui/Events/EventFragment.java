package com.example.sportresult.ui.Events;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.Result;
import com.example.sportresult.R;
import com.example.sportresult.ui.Sport.SportsFragment;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class EventFragment extends Fragment {
    private ListView listViewTeam;
    private ApiClient apiClient;
    public EventFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_team, container, false);
        listViewTeam = (ListView) root.findViewById(R.id.teamList);
        apiClient = new ApiClient(this.getContext());
        Bundle args = getArguments();
        List<Result> resultList = null;

        try{
            ByteArrayInputStream bis = new ByteArrayInputStream(args.getByteArray("Events"));
            ObjectInputStream ois = new ObjectInputStream(bis);
            resultList = (List<Result>) ois.readObject();
            if(resultList !=  null){
                EventArrayAdapter eaa = new EventArrayAdapter(getActivity(), resultList);
                listViewTeam.setAdapter(eaa);
            }else{
                Toast.makeText(getContext(),"Sin resultados, haga click en \"Atras\" ",Toast.LENGTH_LONG);
            }
            bis.close();
            ois.close();

        }catch(IOException ioe){
            ioe.printStackTrace();
        }catch(ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }

        return root;
    }
}
