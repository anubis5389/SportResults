package com.example.sportresult.API;

import com.example.sportresult.Clases.*;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

//baseurl https://www.thesportsdb.com/api/v1/json/1/

public interface SportsDBGet {
    //SEARCH
    @GET("all_sports.php")
    Call<SportList> getAllSports();

    @GET("search_all_leagues.php?")
    Call<CountryLeagueList> getAllLeaguesForCountryAndSport(@Query("s") String sport,@Query("c") String country);

    @GET("all_countries.php")
    Call<CountryList> getAllCountries();

    @GET("search_all_teams.php?")
    Call<TeamList> getAllTeamFromLeague(@Query("l") String league);

    @GET("searchteams.php?")
    Call<TeamList> getTeamByName(@Query("t") String team);

    //SCHEDULES
    //POR EQUIPO
    @GET("eventslast.php?")
    Call<EventList> getLastEventsByTeamId(@Query("id") String teamId);




}
