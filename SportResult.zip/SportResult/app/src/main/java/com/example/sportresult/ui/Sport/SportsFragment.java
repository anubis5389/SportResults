package com.example.sportresult.ui.Sport;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.Clases.Sport;
import com.example.sportresult.R;
import com.example.sportresult.ui.Country.CountryFragment;
import com.example.sportresult.ui.CountryLeague.CountryLeagueFragment;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class SportsFragment extends Fragment {
    public ApiClient clientCalls;
    public ListView listViewSports;
    public SportsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_sports, container, false);
        listViewSports = (ListView) root.findViewById(R.id.sportsList);
        clientCalls = new ApiClient(this.getContext());
        List<Sport> sportList = recuperarDatosApi();
        SportsArrayAdapter saa = new SportsArrayAdapter(getActivity(), sportList);

        listViewSports.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Sport selectedSport = (Sport)listViewSports.getItemAtPosition(position);
                Bundle args = new Bundle();

                args.putString("Sport",selectedSport.getStrSport());
                CountryFragment fragment = new CountryFragment();
                fragment.setArguments(args);
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainer,fragment).addToBackStack("SportToCountry");
                fragmentTransaction.commit();

            }
        });

        listViewSports.setAdapter(saa);
        return root;
    }
    public List<Sport> recuperarDatosApi(){
        return clientCalls.getAllSports();
    }

}
