package com.example.sportresult.Clases;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idTeam",
        "idSoccerXML",
        "idAPIfootball",
        "intLoved",
        "strTeam",
        "strTeamShort",
        "strAlternate",
        "intFormedYear",
        "strSport",
        "strLeague",
        "idLeague",
        "strDivision",
        "strManager",
        "strStadium",
        "strKeywords",
        "strRSS",
        "strStadiumThumb",
        "strStadiumDescription",
        "strStadiumLocation",
        "intStadiumCapacity",
        "strWebsite",
        "strFacebook",
        "strTwitter",
        "strInstagram",
        "strDescriptionEN",
        "strDescriptionDE",
        "strDescriptionFR",
        "strDescriptionCN",
        "strDescriptionIT",
        "strDescriptionJP",
        "strDescriptionRU",
        "strDescriptionES",
        "strDescriptionPT",
        "strDescriptionSE",
        "strDescriptionNL",
        "strDescriptionHU",
        "strDescriptionNO",
        "strDescriptionIL",
        "strDescriptionPL",
        "strGender",
        "strCountry",
        "strTeamBadge",
        "strTeamJersey",
        "strTeamLogo",
        "strTeamFanart1",
        "strTeamFanart2",
        "strTeamFanart3",
        "strTeamFanart4",
        "strTeamBanner",
        "strYoutube",
        "strLocked"
})
public class Team implements Serializable {

    @JsonProperty("idTeam")
    private String idTeam;
    @JsonProperty("idSoccerXML")
    private Object idSoccerXML;
    @JsonProperty("idAPIfootball")
    private String idAPIfootball;
    @JsonProperty("intLoved")
    private Object intLoved;
    @JsonProperty("strTeam")
    private String strTeam;
    @JsonProperty("strTeamShort")
    private Object strTeamShort;
    @JsonProperty("strAlternate")
    private String strAlternate;
    @JsonProperty("intFormedYear")
    private String intFormedYear;
    @JsonProperty("strSport")
    private String strSport;
    @JsonProperty("strLeague")
    private String strLeague;
    @JsonProperty("idLeague")
    private String idLeague;
    @JsonProperty("strDivision")
    private Object strDivision;
    @JsonProperty("strManager")
    private String strManager;
    @JsonProperty("strStadium")
    private String strStadium;
    @JsonProperty("strKeywords")
    private String strKeywords;
    @JsonProperty("strRSS")
    private String strRSS;
    @JsonProperty("strStadiumThumb")
    private Object strStadiumThumb;
    @JsonProperty("strStadiumDescription")
    private Object strStadiumDescription;
    @JsonProperty("strStadiumLocation")
    private String strStadiumLocation;
    @JsonProperty("intStadiumCapacity")
    private String intStadiumCapacity;
    @JsonProperty("strWebsite")
    private String strWebsite;
    @JsonProperty("strFacebook")
    private String strFacebook;
    @JsonProperty("strTwitter")
    private String strTwitter;
    @JsonProperty("strInstagram")
    private String strInstagram;
    @JsonProperty("strDescriptionEN")
    private String strDescriptionEN;
    @JsonProperty("strDescriptionDE")
    private Object strDescriptionDE;
    @JsonProperty("strDescriptionFR")
    private Object strDescriptionFR;
    @JsonProperty("strDescriptionCN")
    private Object strDescriptionCN;
    @JsonProperty("strDescriptionIT")
    private Object strDescriptionIT;
    @JsonProperty("strDescriptionJP")
    private Object strDescriptionJP;
    @JsonProperty("strDescriptionRU")
    private Object strDescriptionRU;
    @JsonProperty("strDescriptionES")
    private Object strDescriptionES;
    @JsonProperty("strDescriptionPT")
    private Object strDescriptionPT;
    @JsonProperty("strDescriptionSE")
    private Object strDescriptionSE;
    @JsonProperty("strDescriptionNL")
    private Object strDescriptionNL;
    @JsonProperty("strDescriptionHU")
    private Object strDescriptionHU;
    @JsonProperty("strDescriptionNO")
    private Object strDescriptionNO;
    @JsonProperty("strDescriptionIL")
    private Object strDescriptionIL;
    @JsonProperty("strDescriptionPL")
    private Object strDescriptionPL;
    @JsonProperty("strGender")
    private String strGender;
    @JsonProperty("strCountry")
    private String strCountry;
    @JsonProperty("strTeamBadge")
    private String strTeamBadge;
    @JsonProperty("strTeamJersey")
    private Object strTeamJersey;
    @JsonProperty("strTeamLogo")
    private Object strTeamLogo;
    @JsonProperty("strTeamFanart1")
    private Object strTeamFanart1;
    @JsonProperty("strTeamFanart2")
    private Object strTeamFanart2;
    @JsonProperty("strTeamFanart3")
    private Object strTeamFanart3;
    @JsonProperty("strTeamFanart4")
    private Object strTeamFanart4;
    @JsonProperty("strTeamBanner")
    private Object strTeamBanner;
    @JsonProperty("strYoutube")
    private String strYoutube;
    @JsonProperty("strLocked")
    private String strLocked;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("idTeam")
    public String getIdTeam() {
        return idTeam;
    }

    @JsonProperty("idTeam")
    public void setIdTeam(String idTeam) {
        this.idTeam = idTeam;
    }

    @JsonProperty("idSoccerXML")
    public Object getIdSoccerXML() {
        return idSoccerXML;
    }

    @JsonProperty("idSoccerXML")
    public void setIdSoccerXML(Object idSoccerXML) {
        this.idSoccerXML = idSoccerXML;
    }

    @JsonProperty("idAPIfootball")
    public String getIdAPIfootball() {
        return idAPIfootball;
    }

    @JsonProperty("idAPIfootball")
    public void setIdAPIfootball(String idAPIfootball) {
        this.idAPIfootball = idAPIfootball;
    }

    @JsonProperty("intLoved")
    public Object getIntLoved() {
        return intLoved;
    }

    @JsonProperty("intLoved")
    public void setIntLoved(Object intLoved) {
        this.intLoved = intLoved;
    }

    @JsonProperty("strTeam")
    public String getStrTeam() {
        return strTeam;
    }

    @JsonProperty("strTeam")
    public void setStrTeam(String strTeam) {
        this.strTeam = strTeam;
    }

    @JsonProperty("strTeamShort")
    public Object getStrTeamShort() {
        return strTeamShort;
    }

    @JsonProperty("strTeamShort")
    public void setStrTeamShort(Object strTeamShort) {
        this.strTeamShort = strTeamShort;
    }

    @JsonProperty("strAlternate")
    public String getStrAlternate() {
        return strAlternate;
    }

    @JsonProperty("strAlternate")
    public void setStrAlternate(String strAlternate) {
        this.strAlternate = strAlternate;
    }

    @JsonProperty("intFormedYear")
    public String getIntFormedYear() {
        return intFormedYear;
    }

    @JsonProperty("intFormedYear")
    public void setIntFormedYear(String intFormedYear) {
        this.intFormedYear = intFormedYear;
    }

    @JsonProperty("strSport")
    public String getStrSport() {
        return strSport;
    }

    @JsonProperty("strSport")
    public void setStrSport(String strSport) {
        this.strSport = strSport;
    }

    @JsonProperty("strLeague")
    public String getStrLeague() {
        return strLeague;
    }

    @JsonProperty("strLeague")
    public void setStrLeague(String strLeague) {
        this.strLeague = strLeague;
    }

    @JsonProperty("idLeague")
    public String getIdLeague() {
        return idLeague;
    }

    @JsonProperty("idLeague")
    public void setIdLeague(String idLeague) {
        this.idLeague = idLeague;
    }

    @JsonProperty("strDivision")
    public Object getStrDivision() {
        return strDivision;
    }

    @JsonProperty("strDivision")
    public void setStrDivision(Object strDivision) {
        this.strDivision = strDivision;
    }

    @JsonProperty("strManager")
    public String getStrManager() {
        return strManager;
    }

    @JsonProperty("strManager")
    public void setStrManager(String strManager) {
        this.strManager = strManager;
    }

    @JsonProperty("strStadium")
    public String getStrStadium() {
        return strStadium;
    }

    @JsonProperty("strStadium")
    public void setStrStadium(String strStadium) {
        this.strStadium = strStadium;
    }

    @JsonProperty("strKeywords")
    public String getStrKeywords() {
        return strKeywords;
    }

    @JsonProperty("strKeywords")
    public void setStrKeywords(String strKeywords) {
        this.strKeywords = strKeywords;
    }

    @JsonProperty("strRSS")
    public String getStrRSS() {
        return strRSS;
    }

    @JsonProperty("strRSS")
    public void setStrRSS(String strRSS) {
        this.strRSS = strRSS;
    }

    @JsonProperty("strStadiumThumb")
    public Object getStrStadiumThumb() {
        return strStadiumThumb;
    }

    @JsonProperty("strStadiumThumb")
    public void setStrStadiumThumb(Object strStadiumThumb) {
        this.strStadiumThumb = strStadiumThumb;
    }

    @JsonProperty("strStadiumDescription")
    public Object getStrStadiumDescription() {
        return strStadiumDescription;
    }

    @JsonProperty("strStadiumDescription")
    public void setStrStadiumDescription(Object strStadiumDescription) {
        this.strStadiumDescription = strStadiumDescription;
    }

    @JsonProperty("strStadiumLocation")
    public String getStrStadiumLocation() {
        return strStadiumLocation;
    }

    @JsonProperty("strStadiumLocation")
    public void setStrStadiumLocation(String strStadiumLocation) {
        this.strStadiumLocation = strStadiumLocation;
    }

    @JsonProperty("intStadiumCapacity")
    public String getIntStadiumCapacity() {
        return intStadiumCapacity;
    }

    @JsonProperty("intStadiumCapacity")
    public void setIntStadiumCapacity(String intStadiumCapacity) {
        this.intStadiumCapacity = intStadiumCapacity;
    }

    @JsonProperty("strWebsite")
    public String getStrWebsite() {
        return strWebsite;
    }

    @JsonProperty("strWebsite")
    public void setStrWebsite(String strWebsite) {
        this.strWebsite = strWebsite;
    }

    @JsonProperty("strFacebook")
    public String getStrFacebook() {
        return strFacebook;
    }

    @JsonProperty("strFacebook")
    public void setStrFacebook(String strFacebook) {
        this.strFacebook = strFacebook;
    }

    @JsonProperty("strTwitter")
    public String getStrTwitter() {
        return strTwitter;
    }

    @JsonProperty("strTwitter")
    public void setStrTwitter(String strTwitter) {
        this.strTwitter = strTwitter;
    }

    @JsonProperty("strInstagram")
    public String getStrInstagram() {
        return strInstagram;
    }

    @JsonProperty("strInstagram")
    public void setStrInstagram(String strInstagram) {
        this.strInstagram = strInstagram;
    }

    @JsonProperty("strDescriptionEN")
    public String getStrDescriptionEN() {
        return strDescriptionEN;
    }

    @JsonProperty("strDescriptionEN")
    public void setStrDescriptionEN(String strDescriptionEN) {
        this.strDescriptionEN = strDescriptionEN;
    }

    @JsonProperty("strDescriptionDE")
    public Object getStrDescriptionDE() {
        return strDescriptionDE;
    }

    @JsonProperty("strDescriptionDE")
    public void setStrDescriptionDE(Object strDescriptionDE) {
        this.strDescriptionDE = strDescriptionDE;
    }

    @JsonProperty("strDescriptionFR")
    public Object getStrDescriptionFR() {
        return strDescriptionFR;
    }

    @JsonProperty("strDescriptionFR")
    public void setStrDescriptionFR(Object strDescriptionFR) {
        this.strDescriptionFR = strDescriptionFR;
    }

    @JsonProperty("strDescriptionCN")
    public Object getStrDescriptionCN() {
        return strDescriptionCN;
    }

    @JsonProperty("strDescriptionCN")
    public void setStrDescriptionCN(Object strDescriptionCN) {
        this.strDescriptionCN = strDescriptionCN;
    }

    @JsonProperty("strDescriptionIT")
    public Object getStrDescriptionIT() {
        return strDescriptionIT;
    }

    @JsonProperty("strDescriptionIT")
    public void setStrDescriptionIT(Object strDescriptionIT) {
        this.strDescriptionIT = strDescriptionIT;
    }

    @JsonProperty("strDescriptionJP")
    public Object getStrDescriptionJP() {
        return strDescriptionJP;
    }

    @JsonProperty("strDescriptionJP")
    public void setStrDescriptionJP(Object strDescriptionJP) {
        this.strDescriptionJP = strDescriptionJP;
    }

    @JsonProperty("strDescriptionRU")
    public Object getStrDescriptionRU() {
        return strDescriptionRU;
    }

    @JsonProperty("strDescriptionRU")
    public void setStrDescriptionRU(Object strDescriptionRU) {
        this.strDescriptionRU = strDescriptionRU;
    }

    @JsonProperty("strDescriptionES")
    public Object getStrDescriptionES() {
        return strDescriptionES;
    }

    @JsonProperty("strDescriptionES")
    public void setStrDescriptionES(Object strDescriptionES) {
        this.strDescriptionES = strDescriptionES;
    }

    @JsonProperty("strDescriptionPT")
    public Object getStrDescriptionPT() {
        return strDescriptionPT;
    }

    @JsonProperty("strDescriptionPT")
    public void setStrDescriptionPT(Object strDescriptionPT) {
        this.strDescriptionPT = strDescriptionPT;
    }

    @JsonProperty("strDescriptionSE")
    public Object getStrDescriptionSE() {
        return strDescriptionSE;
    }

    @JsonProperty("strDescriptionSE")
    public void setStrDescriptionSE(Object strDescriptionSE) {
        this.strDescriptionSE = strDescriptionSE;
    }

    @JsonProperty("strDescriptionNL")
    public Object getStrDescriptionNL() {
        return strDescriptionNL;
    }

    @JsonProperty("strDescriptionNL")
    public void setStrDescriptionNL(Object strDescriptionNL) {
        this.strDescriptionNL = strDescriptionNL;
    }

    @JsonProperty("strDescriptionHU")
    public Object getStrDescriptionHU() {
        return strDescriptionHU;
    }

    @JsonProperty("strDescriptionHU")
    public void setStrDescriptionHU(Object strDescriptionHU) {
        this.strDescriptionHU = strDescriptionHU;
    }

    @JsonProperty("strDescriptionNO")
    public Object getStrDescriptionNO() {
        return strDescriptionNO;
    }

    @JsonProperty("strDescriptionNO")
    public void setStrDescriptionNO(Object strDescriptionNO) {
        this.strDescriptionNO = strDescriptionNO;
    }

    @JsonProperty("strDescriptionIL")
    public Object getStrDescriptionIL() {
        return strDescriptionIL;
    }

    @JsonProperty("strDescriptionIL")
    public void setStrDescriptionIL(Object strDescriptionIL) {
        this.strDescriptionIL = strDescriptionIL;
    }

    @JsonProperty("strDescriptionPL")
    public Object getStrDescriptionPL() {
        return strDescriptionPL;
    }

    @JsonProperty("strDescriptionPL")
    public void setStrDescriptionPL(Object strDescriptionPL) {
        this.strDescriptionPL = strDescriptionPL;
    }

    @JsonProperty("strGender")
    public String getStrGender() {
        return strGender;
    }

    @JsonProperty("strGender")
    public void setStrGender(String strGender) {
        this.strGender = strGender;
    }

    @JsonProperty("strCountry")
    public String getStrCountry() {
        return strCountry;
    }

    @JsonProperty("strCountry")
    public void setStrCountry(String strCountry) {
        this.strCountry = strCountry;
    }

    @JsonProperty("strTeamBadge")
    public String getStrTeamBadge() {
        return strTeamBadge;
    }

    @JsonProperty("strTeamBadge")
    public void setStrTeamBadge(String strTeamBadge) {
        this.strTeamBadge = strTeamBadge;
    }

    @JsonProperty("strTeamJersey")
    public Object getStrTeamJersey() {
        return strTeamJersey;
    }

    @JsonProperty("strTeamJersey")
    public void setStrTeamJersey(Object strTeamJersey) {
        this.strTeamJersey = strTeamJersey;
    }

    @JsonProperty("strTeamLogo")
    public Object getStrTeamLogo() {
        return strTeamLogo;
    }

    @JsonProperty("strTeamLogo")
    public void setStrTeamLogo(Object strTeamLogo) {
        this.strTeamLogo = strTeamLogo;
    }

    @JsonProperty("strTeamFanart1")
    public Object getStrTeamFanart1() {
        return strTeamFanart1;
    }

    @JsonProperty("strTeamFanart1")
    public void setStrTeamFanart1(Object strTeamFanart1) {
        this.strTeamFanart1 = strTeamFanart1;
    }

    @JsonProperty("strTeamFanart2")
    public Object getStrTeamFanart2() {
        return strTeamFanart2;
    }

    @JsonProperty("strTeamFanart2")
    public void setStrTeamFanart2(Object strTeamFanart2) {
        this.strTeamFanart2 = strTeamFanart2;
    }

    @JsonProperty("strTeamFanart3")
    public Object getStrTeamFanart3() {
        return strTeamFanart3;
    }

    @JsonProperty("strTeamFanart3")
    public void setStrTeamFanart3(Object strTeamFanart3) {
        this.strTeamFanart3 = strTeamFanart3;
    }

    @JsonProperty("strTeamFanart4")
    public Object getStrTeamFanart4() {
        return strTeamFanart4;
    }

    @JsonProperty("strTeamFanart4")
    public void setStrTeamFanart4(Object strTeamFanart4) {
        this.strTeamFanart4 = strTeamFanart4;
    }

    @JsonProperty("strTeamBanner")
    public Object getStrTeamBanner() {
        return strTeamBanner;
    }

    @JsonProperty("strTeamBanner")
    public void setStrTeamBanner(Object strTeamBanner) {
        this.strTeamBanner = strTeamBanner;
    }

    @JsonProperty("strYoutube")
    public String getStrYoutube() {
        return strYoutube;
    }

    @JsonProperty("strYoutube")
    public void setStrYoutube(String strYoutube) {
        this.strYoutube = strYoutube;
    }

    @JsonProperty("strLocked")
    public String getStrLocked() {
        return strLocked;
    }

    @JsonProperty("strLocked")
    public void setStrLocked(String strLocked) {
        this.strLocked = strLocked;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}