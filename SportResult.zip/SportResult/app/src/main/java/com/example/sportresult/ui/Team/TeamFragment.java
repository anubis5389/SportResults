package com.example.sportresult.ui.Team;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.Result;
import com.example.sportresult.Clases.Team;
import com.example.sportresult.R;
import com.example.sportresult.ui.Events.EventFragment;
import com.example.sportresult.ui.Sport.SportsFragment;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class TeamFragment extends Fragment {
    private ListView listViewTeam;
    private ApiClient apiClient;
    public TeamFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_team, container, false);
        listViewTeam = (ListView) root.findViewById(R.id.teamList);
        apiClient = new ApiClient(this.getContext());
        Bundle args = getArguments();
        final List<Team> teamList = apiClient.getAllTeamFromLeague(args.getString("Liga"));
        TeamArrayAdapter saa = new TeamArrayAdapter(getActivity(), teamList);

        listViewTeam.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Team selectedTeam = (Team)listViewTeam.getItemAtPosition(position);
                byte[] bytes = null;
                byte[] byteTeams = null;
                Bundle args = getArguments();
                List<Result> results = apiClient.getLastEventsByTeamId(selectedTeam.getIdTeam());
                try{
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(bos);
                    oos.writeObject(results);
                    bytes = bos.toByteArray();
                    oos.flush();
                    bos.flush();
                    oos.writeObject(teamList);
                    byteTeams = bos.toByteArray();

                    oos.close();
                    bos.close();

                }catch(Exception e){
                    e.printStackTrace();
                }

                args.putByteArray("Events",bytes);
//                args.putByteArray("Teams",byteTeams);
                EventFragment fragment = new EventFragment();
                fragment.setArguments(args);

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainer,fragment).addToBackStack("TeamToResult");
                fragmentTransaction.commit();
            }
        });
        try {
            listViewTeam.setAdapter(saa);
        }catch(NullPointerException npe){
            npe.printStackTrace();
            SportsFragment aux = new SportsFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragmentContainer, aux).addToBackStack("BackToBegin");
            fragmentTransaction.commit();
        }


        return root;
    }
}
