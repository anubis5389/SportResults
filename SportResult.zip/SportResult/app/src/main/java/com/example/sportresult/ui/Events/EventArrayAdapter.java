package com.example.sportresult.ui.Events;

import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.Result;
import com.example.sportresult.Clases.Team;
import com.example.sportresult.R;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.List;

public class EventArrayAdapter extends ArrayAdapter<Result> {
    private final Context context;
    private List<Result> lista = null;
    private ApiClient apiClient;

    public EventArrayAdapter(Context context, List<Result> lista){
        super(context, R.layout.events_item_list,lista);

        this.context = context;
        this.lista = lista;

    }
    public View getView(int position, View view, ViewGroup parent){
        LayoutInflater inflater = LayoutInflater.from(context);
//        context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.events_item_list,null,true);

        TextView homeScore = (TextView) rowView.findViewById(R.id.homeScore);
        ImageView homeImage = (ImageView) rowView.findViewById(R.id.homeImage);
        ImageView awayImage = (ImageView) rowView.findViewById(R.id.awayImage);
        TextView awayScore = (TextView) rowView.findViewById(R.id.awayScore);


        apiClient = new ApiClient(context);
        Team home = apiClient.getTeamByName(lista.get(position).getStrHomeTeam());
        Team away = apiClient.getTeamByName(lista.get(position).getStrAwayTeam());


        homeScore.setText(lista.get(position).getIntHomeScore());
        homeScore.setTextSize(TypedValue.COMPLEX_UNIT_SP,50);

        Picasso.get().load(home.getStrTeamBadge()).into(homeImage);
        Picasso.get().load(away.getStrTeamBadge()).into(awayImage);

        awayScore.setText(lista.get(position).getIntAwayScore());
        awayScore.setTextSize(TypedValue.COMPLEX_UNIT_SP,50);

        return rowView;
    }
}
