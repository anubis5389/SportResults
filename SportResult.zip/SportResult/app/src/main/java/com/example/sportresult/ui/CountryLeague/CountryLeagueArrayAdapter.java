package com.example.sportresult.ui.CountryLeague;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CountryLeagueArrayAdapter extends ArrayAdapter<CountryLeague> {
    private final Context context;
    private List<CountryLeague> lista = null;
    public CountryLeagueArrayAdapter(Context context, List<CountryLeague> lista) {
        super(context, R.layout.custom_item_list,lista);

        this.context = context;
        this.lista = lista;
    }

    public View getView(int position, View view, ViewGroup parent){
        LayoutInflater inflater = LayoutInflater.from(context);
//                context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.custom_item_list,null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.subtitle);

        titleText.setText(lista.get(position).getStrCountry());
        Picasso.get().load(lista.get(position).getStrBadge()).into(imageView);
        subtitleText.setText(lista.get(position).getStrLeague());

        return rowView;
    }
}
