package com.example.sportresult.ui.CountryLeague;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.sportresult.API.ApiClient;
import com.example.sportresult.Clases.CountryLeague;
import com.example.sportresult.Clases.Team;
import com.example.sportresult.R;
import com.example.sportresult.ui.Sport.SportsFragment;
import com.example.sportresult.ui.Team.TeamFragment;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CountryLeagueFragment extends Fragment {
    private ApiClient apiClient;
    public ListView listViewCountryLeague;
    public CountryLeagueFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_country_league, container, false);
        listViewCountryLeague = (ListView) root.findViewById(R.id.countryleaguelist);
        Bundle args = getArguments();
        List<CountryLeague> listaLigas = null;
        try{
            ByteArrayInputStream bis = new ByteArrayInputStream(args.getByteArray("LeagueListForCountryAndSport"));
            ObjectInputStream ois = new ObjectInputStream(bis);
            listaLigas = (List<CountryLeague>) ois.readObject();


        }catch(IOException ioe){
            ioe.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        listViewCountryLeague.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                CountryLeague selectedCountryLeague = (CountryLeague)listViewCountryLeague.getItemAtPosition(position);
                Bundle arguments = getArguments();
                arguments.putString("Liga",selectedCountryLeague.getStrLeague());
                String asdf = selectedCountryLeague.getStrLeague();

                TeamFragment teamFragment = new TeamFragment();
                teamFragment.setArguments(arguments);
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainer, teamFragment).addToBackStack("LeagueToTeams");
                fragmentTransaction.commit();

            }
        });
        try {
            if(listaLigas!=null){
                CountryLeagueArrayAdapter claa = new CountryLeagueArrayAdapter(getActivity(),listaLigas);
                listViewCountryLeague.setAdapter(claa);
            }else{

            }

        }catch(NullPointerException npe){
            npe.printStackTrace();
            SportsFragment aux = new SportsFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragmentContainer, aux).addToBackStack("BackToBegin");
            fragmentTransaction.commit();
        }

        return root;

    }
}
